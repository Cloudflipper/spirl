#import os

#from spirl.data.block_stacking.src.robosuite.environments.base import make
#from spirl.data.block_stacking.src.robosuite.environments.sawyer_lift import SawyerLift
#from spirl.data.block_stacking.src.robosuite.environments.sawyer_stack import SawyerStack
#from spirl.data.block_stacking.src.robosuite.environments.sawyer_pick_place import SawyerPickPlace
#from spirl.data.block_stacking.src.robosuite.environments.sawyer_nut_assembly import SawyerNutAssembly

#from spirl.data.block_stacking.src.robosuite.environments.baxter_lift import BaxterLift
#from spirl.data.block_stacking.src.robosuite.environments.baxter_peg_in_hole import BaxterPegInHole
#from spirl.data.block_stacking.src.robosuite.environments.baxter_modified import BaxterChange

__version__ = "0.3.0"
__logo__ = """
      ;     /        ,--.
     ["]   ["]  ,<  |__**|
    /[_]\  [~]\/    |//  |
     ] [   OOO      /o|__|
"""
